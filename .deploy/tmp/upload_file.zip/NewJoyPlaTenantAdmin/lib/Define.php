<?php
require_once "Define.php";

define('APITITLE', "JoyPla");
define('CHARSET', 'UTF-8');
define('REPLACE_FLAGS', ENT_QUOTES);

define('FROM_ADDRESS', "joypla-spd@pi-pe.co.jp");
define('FROM_NAME', "joypla");
define('HP_MAIL_FIELD_TITLE', "mailAddress");
define('OROSHI_MAIL_FIELD_TITLE', "mailAddress");