<nav class="uk-navbar-container no_print" uk-navbar>
    <div class="uk-navbar-left">
    </div>
</nav>