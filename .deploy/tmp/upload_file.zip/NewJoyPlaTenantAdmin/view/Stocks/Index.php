<div class="uk-section uk-section-default uk-preserve-color uk-padding-remove">
    <div class="uk-container uk-container-expand">
    	<h1>在庫管理</h1>
		<div class="uk-margin spiral_table_area" style="display:none">
			%sf:usr:search51%
		</div>
    </div>
</div>
