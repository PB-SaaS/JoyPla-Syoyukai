<?php echo $name ?> 様
            
JoyPla からお知らせです。

次のトピックに返信がありました。

【タイトル】<?php echo $topicTitle ?> 

【投稿者】<?php echo $commentUser ?> 

下記URLよりログインしてご確認ください
<?php echo $login_url ?> 

※このメールへの返信は受け付けていません。