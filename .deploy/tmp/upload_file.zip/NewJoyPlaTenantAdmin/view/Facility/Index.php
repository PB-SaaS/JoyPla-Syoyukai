<div class="uk-section uk-section-default uk-preserve-color uk-padding-remove">
    <div class="uk-container uk-container-expand">
    	<h1>病院情報管理</h1>
		<div class="uk-margin spiral_table_area" style="display:none">
			%sf:usr:search4%
		</div>
    </div>
</div>
