<div class="uk-section uk-section-default uk-preserve-color uk-padding-remove">
    <div class="uk-container uk-container-expand">
    	<h1>金額管理</h1>
		<div class="uk-margin spiral_table_area" style="display:none">
			%sf:usr:search29%
		</div>
    </div>
</div>
