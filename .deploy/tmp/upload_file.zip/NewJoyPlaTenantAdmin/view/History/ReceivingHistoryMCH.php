<div class="uk-section uk-section-default uk-preserve-color uk-padding-remove uk-margin-top">
    <div class="uk-container uk-container-expand">
    	<h1>入庫実績（MCH様）</h1>
    	<div class="uk-margin spiral_table_area" style="display:none">
    		%sf:usr:search8%
    	</div>
    </div>
</div>
