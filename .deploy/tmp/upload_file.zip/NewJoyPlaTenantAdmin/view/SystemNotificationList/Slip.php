  	<div class="uk-section uk-section-default uk-preserve-color uk-padding-remove uk-margin-top" id="page_top">
	    <div class="uk-container uk-container-expand">
	    	<div class="uk-margin-auto uk-width-2-3@m">
	    		<article class="uk-article uk-margin-bottom">

				    <h1 class="uk-article-title">%val:usr:title%</h1>
				
				    <p class="uk-article-meta">作成者 %val:usr:creator%</p>
				
				    <p class="">%val:usr:content:br%</p>
					<div class="uk-grid-small uk-child-width-auto uk-grid" uk-grid>
							<div class="uk-width-1-2 uk-first-column">
					    		%val:usr:registrationTime%
							</div>
					    </div>
				</article>
			</div>
		</div>
	</div>
