
<div class="uk-section uk-section-default uk-preserve-color uk-padding-remove uk-margin-top">
    <div class="uk-container uk-container-expand">
    	<h1>商品情報一覧</h1>
		<div class="uk-margin spiral_table_area" style="display:none">
			%sf:usr:search3%
		</div>
    </div>
</div>
