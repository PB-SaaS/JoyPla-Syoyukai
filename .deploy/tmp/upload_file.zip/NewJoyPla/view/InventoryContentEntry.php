<style>
    .id{
      min-width: 24px;
      max-width: 24px;
    }
    
    .shouhin-data .itemName{
      font-size: 14px;
    }
    .shouhin-data .makerName{
      font-size: 12px;
      
    }
    .shouhin-data .tana{
      font-size: 8px;
    }
    .shouhin-data .itemCode{
      font-size: 8px;
      
    }
    .shouhin-data .constant{
      font-size: 8px;
      
    }
    .shouhin-data .quantity{
      font-size: 8px;
      
    }
    .shouhin-data .price{
      font-size: 8px;
      
    }
    .shouhin-data .JANCode{
      font-size: 8px;
      
    }
    .shouhin-data .officialFlag{
      font-size: 8px;
      
    }
    .itemCount{
      position: relative;
    }
    .itemCount->after {
       content: attr(data-format); /* ここが重要!! */
       width: 10%;
       height: 20px;
       position: absolute;
       bottom: 4px;
    }
    .itemCountInput{
      width: 90%;
    }
    .uk-table th, .uk-table td{
      word-break: break-word;
      padding: 12px 8px;
      vertical-align: middle;
    }
    .uk-table tfoot tr{
      border-bottom: #e5e5e5 1px solid;
      border-top: #e5e5e5 1px solid;
    }
    
    table.uk-table {
      counter-reset: rowCount;
    }

    table.uk-table > tbody > tr {
      counter-increment: rowCount;
    }

    table.uk-table > tbody > tr > td:first-child::before {
      content: counter(rowCount);
    }
</style>
<div class="animsition" uk-height-viewport="expand: true">
    <div class="uk-section uk-section-default uk-preserve-color uk-padding-remove uk-margin-top" id="page_top">
        <div class="uk-container uk-container-expand">
            <ul class="uk-breadcrumb">
                <li><a href="%url/rel:mpg:top%">TOP</a></li>
                <li><span>棚卸内容入力</span></li>
            </ul>
            <h2 class="page_title">棚卸内容入力</h2>
            <hr>
            <div class="uk-width-1-3@m">
                <div class="uk-margin">
                    <select class="uk-select" name="busyo" v-model="divisionId" v-bind:disabled="division_disabled">
                        <option value="">----- 部署選択 -----</option>
                    <?php
                        foreach($division->data as $data)
                        {
                            if($data->divisionType === '1')
                            {
                                echo '<option value="'.$data->divisionId.'">'.$data->divisionName.'(大倉庫)</option>';
                                echo '<option value="" disabled>--------------------</option>';
                            }
                        }
                        foreach($division->data as $data)
                        {
                            if($data->divisionType === '2')
                            {
                                echo '<option value="'.$data->divisionId.'">'.$data->divisionName.'</option>';
                            }
                        }
                    ?>
                    </select>
                </div>
            </div>
            <div class="uk-margin-bottom">
                <div class="" uk-margin>
                    <button class="uk-button uk-button-default " onclick="sanshouClick()">商品マスタを開く</button>
                    <button class="uk-button uk-button-default" type="submit" onclick="window.print();return false;">印刷プレビュー</button>
                    <button class="uk-button uk-button-primary" onclick="sendInventory()">棚卸入力</button>
                </div>
            </div>

            <div uk-sticky="sel-target: .uk-navbar-container; cls-active: uk-navbar-sticky" class="uk-padding-top uk-background-muted uk-padding-small">
                <form action='#' method="post" onsubmit="barcodeSearch(); return false">
                    <input type="text" class="uk-input uk-width-4-5" placeholder="バーコード入力..." autofocus="true" name="barcode" autocomplete="off">
                    <button class="uk-button uk-button-primary uk-float-right uk-width-1-5 uk-padding-remove" type="submit">検索</button>
                </form>
            </div>

            <div class="uk-margin uk-text-right">
                <button type="button" class="uk-button uk-button-primary" uk-toggle="target: #modal-gs1128">GS1-128で照合</button>
            </div>

            <div class="shouhin-table uk-width-expand uk-overflow-auto">
                <table class="uk-table uk-table-striped uk-text-nowrap">
                    <thead>
                        <tr>
                            <th>id</th>
                            <th>メーカー</th>
                            <th>商品名</th>
                            <th>製品コード</th>
                            <th>規格</th>
                            <th>入数</th>
                            <th>棚卸数量</th>
                            <th>価格</th>
                            <th>単価</th>
                            <th>JANコード</th>
                            <th>卸業者</th>
                            <th>ロット番号</th>
                            <th>使用期限</th>
                            <th></th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                        </tr>
                        <tr>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                        </tr>
                        <tr>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                            <td>&emsp;</td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- This is a button toggling the modal with the default close button -->
<!-- This is the modal with the default close button -->
<div id="modal-gs1128" uk-modal>
    <div class="uk-modal-dialog uk-modal-body">
        <form onsubmit="gs1_128($('#GS1-128').val());return false;" action="#">
            <button class="uk-modal-close" type="button" uk-close></button>
            <h2 class="uk-modal-title">GS1-128 読取</h2>
            <input type="text" class="uk-input" placeholder="GS1-128" id="GS1-128" autofocus="true">
            <p class="uk-text-right">
                <button class="uk-button uk-button-primary" type="button" onclick="gs1_128($('#GS1-128').val());">反映</button>
            </p>
        </form>
    </div>
</div>

<script>
    class Inventory {
        constructor(phpData) {
            this.phpData = phpData;
            this.back();

            this.canAjax = true;
            this.gs1128_object = {};
            this.order_num = $("#hacchu_num").text();
            $("#order_barcode").html("<svg id='barcode_hacchu'></svg>");
            this.notItemsInfo("");
            generateBarcode("barcode_hacchu", this.order_num);
        }
    }
    let phpData = {
        'useUnitPrice': '<?php echo $useUnitPrice; ?>'
    };
    let inventory = new Inventory(phpData);
</script>