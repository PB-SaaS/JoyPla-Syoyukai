<div class="animsition" uk-height-viewport="expand: true">
    <div class="uk-section uk-section-default uk-preserve-color uk-padding-remove uk-margin-top" id="page_top">
        <div class="uk-container uk-container-expand">
            <ul class="uk-breadcrumb no_print">
                <li><a href="%url/rel:mpg:top%">TOP</a></li>
                <li><span>見積依頼一覧</span></li>
            </ul>
            <div class="uk-width-1-1" uk-grid>
                <div class="uk-width-3-4@m">
                    <h2>見積依頼一覧</h2>
                </div>
            </div>
            <hr>
            <div uk-grid="" uk-margin="" class="uk-grid uk-grid-stack">
                <div class="uk-width-1-1 uk-grid-margin uk-first-column uk-margin-small-top">
                </div>
            </div>
            <div class="uk-margin-auto uk-width-4-5@m">
                %sf:usr:search10%
            </div>
        </div>
    </div>
</div>