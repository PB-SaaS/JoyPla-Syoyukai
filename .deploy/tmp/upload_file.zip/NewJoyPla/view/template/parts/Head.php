<?php

require_once "NewJoyPla/src/Head.php";

/**
 * TODO
 * NewJoyPla/src/Headの移行
 */