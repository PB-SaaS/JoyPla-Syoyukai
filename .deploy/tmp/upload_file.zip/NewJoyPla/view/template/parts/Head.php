<?php

require_once "NewJoyPla/src/Head.php";

/**
 * TODO
 * NewJoyPla/src/Headの移行
 */
 ?>
 <script src="https://cdn.jsdelivr.net/npm/vue@2/dist/vue.js"></script>
 
 