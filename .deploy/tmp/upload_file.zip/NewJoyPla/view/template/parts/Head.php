<link rel="icon" href="https://i02.smp.ne.jp/u/joypla/new/favicon.ico">
<meta http-equiv="Content-Type" content="text/html; charset=Shift_JIS">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!-- UIkit CSS -->
<link rel="stylesheet" href="https://i02.smp.ne.jp/u/joypla/new/css/uikit.min.css" />
<link rel="stylesheet" href="https://i02.smp.ne.jp/u/joypla/new/css/normalize.css" />

<!-- UIkit JS --> 
<script src="https://i02.smp.ne.jp/u/joypla/new/js/uikit.min.js"></script>
<script src="https://i02.smp.ne.jp/u/joypla/new/js/uikit-icons.min.js"></script>

<script src="https://i02.smp.ne.jp/u/joypla/new/js/jquery-3.5.1.js"></script>

<!-- <link rel="stylesheet" href="https://i02.smp.ne.jp/u/joypla/new/css/animsition.min.css"> -->
<!-- <script type="text/javascript" src="https://i02.smp.ne.jp/u/joypla/new/js/animsition.min.js"></script> -->

<script src="https://i02.smp.ne.jp/u/joypla/new/js/JsBarcode.all.min.js"></script>
<script src="https://i02.smp.ne.jp/u/joypla/new/js/BarcodeParser.js"></script>


<script src="https://i02.smp.ne.jp/u/joypla/new/js/vue.js"></script>
<script src="https://i02.smp.ne.jp/u/joypla/new/js/encoding.min.js"></script>
<?php

if($new == '')
{
 require_once 'NewJoyPla/view/template/parts/Script.php';
 require_once 'NewJoyPla/view/template/parts/StyleCss.php';
 require_once 'NewJoyPla/view/template/parts/PrintCss.php';
}