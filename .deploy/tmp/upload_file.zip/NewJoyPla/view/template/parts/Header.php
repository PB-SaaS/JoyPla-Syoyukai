<nav class="uk-navbar-container no_print" uk-navbar>
	<div class="uk-navbar-left">
		<a href="%url/rel:mpg:top%" class="uk-navbar-item uk-logo">
			<img src="https://i02.smp.ne.jp/u/joypla/images/logo_png.png" />
		</a>
	</div>

	<div class="uk-navbar-right uk-margin-right" style="flex-wrap: nowrap;">
		<a href="%url/rel:mpg:top%" class="uk-icon-button uk-margin-right" uk-icon="icon: home; ratio: 1.5" title="TOPへ戻る"></a>
		<a href="<?php echo $baseUrl ?>&R=" class="uk-icon-button uk-margin-right" uk-icon="icon: mail; ratio: 1.5" title="お問合せ" ></a>
		<a href="<?php echo $baseUrl ?>&R=" class="uk-icon-button uk-margin-right" uk-icon="icon: mail; ratio: 1.5" title="お問合せ" ></a>
		<a href="%form:act:logout%" class="uk-icon-button" uk-icon="icon: sign-out; ratio: 1.5" title="ログアウト"></a>
	</div>

</nav>