<style>
@media print{ 
	.no_print{
        display: none !important;
    }
	.title_spacing {
		letter-spacing : 0 !important; 
		text-indent: 0 !important;
	}
	* {
		font-size: 8pt !important;
	}
	.uk-overflow-auto {
		overflow: unset !important;
	}
	.uk-text-large {
		font-size: 16pt !important;
	}
	.uk-select {
		font-size: 8pt !important;
		padding-left: 2px !important;
		padding-right: 2px !important;
		border: 0 none !important;
		background-image: none !important;
	}
}
</style>