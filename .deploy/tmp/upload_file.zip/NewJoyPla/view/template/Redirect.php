<!DOCTYPE html>
<html>
<head>
    <title>リダイレクト</title>
    <meta http-equiv="refresh" content="0;URL=<?php echo $url ?>">
</head>
<body>
</body>
</html>