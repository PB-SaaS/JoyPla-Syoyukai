<?php echo $name ?> 様 
 
JoyPla からお知らせです。 

卸業者様より商品の見積金額が登録されました。

【タイトル】<?php echo $request_title ?> 

【作成者】<?php echo $request_Name ?> 

下記URLよりログインしてご確認ください 

<?php echo $url ?> 


※このメールへの返信は受け付けていません。