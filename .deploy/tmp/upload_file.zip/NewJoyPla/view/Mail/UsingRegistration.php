<?php echo $name ?> 様

JoyPla からお知らせです。
貸出品の使用登録がされましたので、下記の通りお知らせします。

[病院名]
病院名 <?php echo $hospital_name ?> 
担当者 <?php echo $hospital_user_name ?> 

[伝票情報]
 
使用日 <?php echo $used_date ?> 

使用番号 <?php echo $used_slip_number ?> 

使用品目 <?php echo $used_item_num ?> (品目) 

合計金額 <?php echo $total_price ?> 
 
下記URLよりログインしてご確認ください 
<?php echo $login_url ?> 
 
※このメールへの返信は受け付けていません。 