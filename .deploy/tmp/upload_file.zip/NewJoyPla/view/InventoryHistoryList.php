  <div class="animsition uk-margin-bottom" uk-height-viewport="expand: true">
  	<div class="uk-section uk-section-default uk-preserve-color uk-padding-remove uk-margin-top" id="page_top">
	    <div class="uk-container uk-container-expand">
	    	<ul class="uk-breadcrumb no_print">
			    <li><a href="%url/rel:mpg:top%">TOP</a></li>
			    <li><span>棚卸履歴一覧</span></li>
			</ul>
	    	<h2 class="page_title">棚卸履歴一覧</h2>
	    	<hr>

	    	<div class="" id="tablearea">
		    	<h3>実施中の棚卸</h3>
		    	<hr>
                  <div>
		    		%sf:usr:inInventory:table%
		    	</div>
		
		
                  <h3>棚卸完了履歴</h3>
		    	<hr>
                  <div>
		    		%sf:usr:inventoryComp:table%
		    	</div>
              </div>
	    </div>
	</div>
</div>
