<nav class="uk-navbar-container no_print" uk-navbar>
    <div class="uk-navbar-left">
        <a href="#" class="uk-navbar-item uk-logo">
            <img src="https://i02.smp.ne.jp/u/joypla/images/logo_png.png" />
        </a>
    </div>
</nav>