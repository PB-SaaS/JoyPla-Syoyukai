<div class="uk-background-muted uk-padding-small"  uk-height-viewport="offset-top: true" style="border-right:#98CB00 1px solid">
	<a href="#" class="uk-navbar-item uk-logo">
	<img src="https://i02.smp.ne.jp/u/joypla/images/logo_png.png" />
	</a>
	<ul class="uk-nav-default uk-nav-parent-icon" uk-nav>
		<li><a href="%url/rel:mpgt:page_263720%"><span class="uk-margin-small-right" uk-icon="icon: thumbnails"></span> テナント管理</a></li>
		<li><a href="#"><span class="uk-margin-small-right" uk-icon="icon: users"></span> 病院管理</a></li>
		<li><a href="#"><span class="uk-margin-small-right" uk-icon="icon: users"></span> 卸業者管理</a></li>
		<li><a href="#"><span class="uk-margin-small-right" uk-icon="icon: album"></span> 商品マスタ管理</a></li>
		<li class="uk-nav-divider"></li>
		<li><a href="#"><span class="uk-margin-small-right" uk-icon="icon: question"></span> お問合せ管理</a></li>
		<li class="uk-nav-divider"></li>
		<li><a href="#"><span class="uk-margin-small-right" uk-icon="icon: sign-out"></span> ログアウト</a></li>
	</ul>
</div>