<div class="uk-container">
    <h3>利用規約</h3>
    <hr>		
    <div class="uk-grid-match uk-padding-small" style="height:1200px">
    <object data="https://i02.smp.ne.jp/u/joypla/new/pdf/joypla-spdkiyaku20.pdf" type="application/pdf" width="100%" height="100%">
        <iframe src="https://i02.smp.ne.jp/u/joypla/new/pdf/joypla-spdkiyaku20.pdf" width="100%" height="100%">
            <p><b>閲覧できない方はこちら</b>: <a href="https://i02.smp.ne.jp/u/joypla/new/pdf/joypla-spdkiyaku20.pdf">PDF をダウンロード</a>.</p>
        </iframe>
    </object>

    </div>
            
</div>