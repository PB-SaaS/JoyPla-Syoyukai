<?php

/***
 * USECASE
 */
namespace JoyPla\Application\Interactors\Api\Received {

    use App\Model\Division;
    use Exception;
    use framework\Exception\NotFoundException;
    use JoyPla\Application\InputPorts\Api\Received\ReceivedRegisterInputData;
    use JoyPla\Application\InputPorts\Api\Received\ReceivedRegisterInputPortInterface;
    use JoyPla\Application\OutputPorts\Api\Received\ReceivedRegisterOutputData;
    use JoyPla\Application\OutputPorts\Api\Received\ReceivedRegisterOutputPortInterface;
    use JoyPla\Enterprise\Models\DateYearMonthDayHourMinutesSecond;
    use JoyPla\Enterprise\Models\OrderId;
    use JoyPla\Enterprise\Models\HospitalId;
    use JoyPla\Enterprise\Models\Lot;
    use JoyPla\Enterprise\Models\LotDate;
    use JoyPla\Enterprise\Models\LotNumber;
    use JoyPla\Enterprise\Models\Order;
    use JoyPla\Enterprise\Models\OrderItemId;
    use JoyPla\Enterprise\Models\OrderStatus;
    use JoyPla\Enterprise\Models\Received;
    use JoyPla\Enterprise\Models\ReceivedId;
    use JoyPla\Enterprise\Models\ReceivedItem;
    use JoyPla\Enterprise\Models\ReceivedItemId;
    use JoyPla\Enterprise\Models\ReceivedQuantity;
    use JoyPla\Enterprise\Models\ReceivedStatus;
    use JoyPla\Enterprise\Models\ReturnQuantity;
    use JoyPla\InterfaceAdapters\GateWays\Repository\OrderRepositoryInterface;
    use JoyPla\InterfaceAdapters\GateWays\Repository\ReceivedRepositoryInterface;
    use JoyPla\InterfaceAdapters\GateWays\Repository\stockRepositoryInterface;

    /**
     * Class ReceivedRegisterInteractor
     * @package JoyPla\Application\Interactors\Api\Received
     */
    class ReceivedRegisterInteractor implements ReceivedRegisterInputPortInterface
    {
        /** @var ReceivedRegisterOutputPortInterface */
        private ReceivedRegisterOutputPortInterface $outputPort;

        /** @var OrderRepositoryInterface */
        private OrderRepositoryInterface $orderRepository;
        
        /** @var ReceivedRepositoryInterface */
        private ReceivedRepositoryInterface $receivedRepository;

        /**
         * ReceivedRegisterInteractor constructor.
         * @param ReceivedRegisterOutputPortInterface $outputPort
         */
        public function __construct(ReceivedRegisterOutputPortInterface $outputPort , OrderRepositoryInterface $orderRepository , ReceivedRepositoryInterface $receivedRepository)
        {
            $this->outputPort = $outputPort;
            $this->orderRepository = $orderRepository;
            $this->receivedRepository = $receivedRepository;
        }

        /**
         * @param ReceivedRegisterInputData $inputData
         */
        public function handle(ReceivedRegisterInputData $inputData)
        {
            $hospitalId = new HospitalId($inputData->user->hospitalId);
            $orders = $this->orderRepository->getOrderByOrderItemId($hospitalId , array_column($inputData->receivedItems, 'orderItemId'));

            $receiveds = [];
            foreach($orders as $orderKey => $order)
            {
                $received = new Received(
                    $order->getOrderId(),
                    (ReceivedId::generate()),
                    (new DateYearMonthDayHourMinutesSecond('now')),
                    [],
                    $order->getHospital(),
                    $order->getDivision(),
                    $order->getDistributor(),
                    new ReceivedStatus(ReceivedStatus::Received)
                );
                $items = $order->getOrderItems();
                foreach($inputData->receivedItems as $requestReceived)
                {
                    foreach($items as $key => &$item){
                        if($item->getOrderItemId()->equal($requestReceived['orderItemId']))
                        {
                            foreach($requestReceived['receiveds'] as $receivedItem)
                            {
                                $receivedQuantity = new ReceivedQuantity((int)$receivedItem['receivedQuantity']);
                                $item = $item->addReceivedQuantity($receivedQuantity);// 入庫数を更新
                                $receivedItems[] = new ReceivedItem(
                                    $item->getOrderItemId(),
                                    $received->getReceivedId(),
                                    (ReceivedItemId::generate()),
                                    $item->getInHospitalItemId(),
                                    $item->getItem(),
                                    $order->getHospital()->getHospitalId(),
                                    $order->getDivision(),
                                    $order->getDistributor(),
                                    $item->getQantity(),
                                    $item->getPrice(),
                                    0,
                                    $receivedQuantity,
                                    (new ReturnQuantity(0)),
                                    (new Lot(
                                        new LotNumber($receivedItem['lotNumber']),
                                        new LotDate($receivedItem['lotDate']),
                                    )),
                                    $item->getItemImage()
                                );
                            }
                        }
                    }
                }
                $order = $order->setOrderItems($items);// オーダーデータを更新
                $orders[$orderKey] = $order->updateOrderStatus();
                $receiveds[] = $received->setReceivedItems($receivedItems);
            }

            $this->orderRepository->saveToArray($hospitalId , $orders , [ 'isReceived' => true ]);
            $this->receivedRepository->saveToArray($hospitalId , $receiveds);
            $this->outputPort->output(new ReceivedRegisterOutputData($receiveds));
        }
    }
}


/***
 * INPUT
 */
namespace JoyPla\Application\InputPorts\Api\Received {

    use Auth;
    use stdClass;

    /**
     * Class ReceivedRegisterInputData
     * @package JoyPla\Application\InputPorts\Api\Received
     */
    class ReceivedRegisterInputData
    {
        /**
         * ReceivedRegisterInputData constructor.
         */
        public function __construct(Auth $user ,array $receivedItems )
        {
            $this->user = $user;
            $this->receivedItems = array_map(function($item){
                $d['orderItemId'] = $item['orderItemId'];
                $d['receiveds'] = array_map(function($item){
                    $s['receivedQuantity'] = $item['receivedUnitQuantity'];
                    $s['lotNumber'] = ($item['lotNumber'])? $item['lotNumber'] : "";
                    $s['lotDate'] = ($item['lotDate'])? $item['lotDate'] : "";
                    return $s;
                }, $item['receiveds']);
                return $d;
            },$receivedItems);
        }
    }

    /**
     * Interface UserCreateInputPortInterface
     * @package JoyPla\Application\InputPorts\Api\Received
    */
    interface ReceivedRegisterInputPortInterface
    {
        /**
         * @param ReceivedRegisterInputData $inputData
         */
        function handle(ReceivedRegisterInputData $inputData);
    }
}

/***
 * OUTPUT
 */
namespace JoyPla\Application\OutputPorts\Api\Received {

    use JoyPla\Enterprise\Models\Received;
    use JoyPla\Enterprise\Models\Stock;

    /**
     * Class ReceivedRegisterOutputData
     * @package JoyPla\Application\OutputPorts\Api\Received;
     */
    class ReceivedRegisterOutputData
    {
        /** @var string */

        /**
         * ReceivedRegisterOutputData constructor.
         */
        public function __construct(array $receiveds)
        {
            $this->receiveds = $receiveds;
        }
    }

    /**
     * Interface ReceivedRegisterOutputPortInterface
     * @package JoyPla\Application\OutputPorts\Api\Received;
    */
    interface ReceivedRegisterOutputPortInterface
    {
        /**
         * @param ReceivedRegisterOutputData $outputData
         */
        function output(ReceivedRegisterOutputData $outputData);
    }
} 