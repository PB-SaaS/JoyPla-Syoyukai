<?php

namespace JoyPla\InterfaceAdapters\GateWays\Repository;

use App\SpiralDb\Distributor;
use App\SpiralDb\InHospitalItemView;
use Collection;
use JoyPla\Enterprise\Models\InHospitalItem;
use JoyPla\Enterprise\Models\HospitalId;

class InHospitalItemRepository implements InHospitalItemRepositoryInterface{

    public function findByHospitalId( HospitalId $hospitalId )
    {
        $InHospitalItem = (InHospitalItemView::where('hospitalId',$hospitalId->value())->get())->data->all();

        $result = [];
        foreach($InHospitalItem as $d)
        {
            $result[] = InHospitalItem::create($d);
        }
 
        return $result;
    }

    public function search( HospitalId $hospitalId ,  object $search): Collection
    {
        $instance = InHospitalItemView::where('hospitalId',$hospitalId->value());
        if($search->itemName !== "")
        {
            $instance->orWhere('itemName',"%".$search->itemName."%","LIKE");
        }
        if($search->makerName !== "")
        {
            $instance->orWhere('makerName',"%".$search->makerName."%","LIKE");
        }
        if($search->itemCode !== "")
        {
            $instance->orWhere('itemCode',"%".$search->itemCode."%","LIKE");
        }
        if($search->itemStandard !== "")
        {
            $instance->orWhere('itemStandard',"%".$search->itemStandard."%","LIKE");
        }
        if($search->itemJANCode !== "")
        {
            $instance->orWhere('itemJANCode',"%".$search->itemJANCode."%","LIKE");
        }
        if(count($search->distributorIds) > 0)
        {
            foreach( $search->distributorIds as $distributorId)
            {
                $instance->orWhere('distributorId',$distributorId);
            }
        }
        return $instance->page($search->currentPage)->paginate($search->perPage);
    }
}

interface InHospitalItemRepositoryInterface 
{
    public function findByHospitalId( HospitalId $hospitalId );
    public function search( HospitalId $hospitalId , object $search);
}