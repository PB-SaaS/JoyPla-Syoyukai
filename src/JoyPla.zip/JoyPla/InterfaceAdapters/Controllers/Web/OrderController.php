<?php

namespace JoyPla\InterfaceAdapters\Controllers\Web ;

use App\SpiralDb\HospitalUser;
use App\SpiralDb\Order as SpiralDbOrder;
use Auth;
use framework\Http\Controller;
use framework\Http\View;
use JoyPla\Application\InputPorts\Web\Order\FixedQuantityOrderInputData;
use JoyPla\Application\InputPorts\Web\Order\FixedQuantityOrderInputPortInterface;
use JoyPla\Application\InputPorts\Web\Order\OrderIndexInputData;
use JoyPla\Application\InputPorts\Web\Order\OrderIndexInputPortInterface;
use JoyPla\Enterprise\Models\OrderStatus;

class OrderController extends Controller
{
    public function register($vars ) {
        $body = View::forge('html/Order/Register', [], false)->render();
        echo view('html/Common/Template', compact('body'), false)->render();
    }

    public function unapprovedShow(){ 
        $body = View::forge('html/Order/UnapprovedShow', [], false)->render();
        echo view('html/Common/Template', compact('body'), false)->render();
    }

    public function unapprovedIndex($vars, OrderIndexInputPortInterface $inputPort ) {
        $inputData = new OrderIndexInputData(($this->request->user())->hospitalId,$vars['orderId'] , true);
        $inputPort->handle($inputData);
    }

    public function fixedQuantityOrder($vars)
    {
        $body = View::forge('html/Order/FixedQuantityOrder', [], false)->render();
        echo view('html/Common/Template', compact('body'), false)->render();
    }
    
    public function show(){
        $body = View::forge('html/Order/Show', [], false)->render();
        echo view('html/Common/Template', compact('body'), false)->render();
    }
    
    public function index($vars, OrderIndexInputPortInterface $inputPort ) {
        $inputData = new OrderIndexInputData(($this->request->user())->hospitalId,$vars['orderId'] , false);
        $inputPort->handle($inputData);
    }
    
    public function print($vars, OrderIndexInputPortInterface $inputPort ) {
        $inputData = new OrderIndexInputData(($this->request->user())->hospitalId,$vars['orderId'] , false);
        $inputPort->handle($inputData);
    }
}

