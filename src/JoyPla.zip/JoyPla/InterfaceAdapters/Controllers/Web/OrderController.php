<?php

namespace JoyPla\InterfaceAdapters\Controllers\Web ;

use framework\Http\Controller;
use framework\Http\View;
use JoyPla\Application\InputPorts\Web\Order\OrderIndexInputData;
use JoyPla\Application\InputPorts\Web\Order\OrderIndexInputPortInterface;

class OrderController extends Controller
{
    public function register($vars ) {
        $body = View::forge('Hospital/html/OrderRegister', [], false)->render();
        echo view('Template', compact('body'), false)->render();
    }

    public function unapprovedShow(){ 
        $body = View::forge('Hospital/html/UnapprovedShow', [], false)->render();
        echo view('Template', compact('body'), false)->render();
    }
}

