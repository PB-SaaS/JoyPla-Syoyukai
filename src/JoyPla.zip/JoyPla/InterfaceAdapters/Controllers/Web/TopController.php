<?php

namespace JoyPla\InterfaceAdapters\Controllers\Web ;

use framework\Http\Controller;
use framework\Http\View;

class TopController extends Controller
{
    public function index($vars) {
        $body = View::forge('Hospital/html/Top', [], false)->render();
        echo view('Template', compact('body'), false)->render();
    }

    public function orderpage($vars) {
        $body = View::forge('Hospital/html/OrderPage', [], false)->render();
        echo view('Template', compact('body'), false)->render();
    }

    public function consumptionpage($vars)
    {
        $body = View::forge('Hospital/html/ConsumptionPage', [], false)->render();
        echo view('Template', compact('body'), false)->render();
    }
}

