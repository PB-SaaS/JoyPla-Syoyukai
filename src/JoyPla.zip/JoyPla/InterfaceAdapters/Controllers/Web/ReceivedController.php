<?php

namespace JoyPla\InterfaceAdapters\Controllers\Web ;

use App\SpiralDb\HospitalUser;
use Auth;
use framework\Http\Controller;
use framework\Http\View;
use JoyPla\Application\InputPorts\Web\Received\OrderReceivedSlipIndexInputData;
use JoyPla\Application\InputPorts\Web\Received\OrderReceivedSlipIndexInputPortInterface;
use JoyPla\Application\InputPorts\Web\Received\ReceivedIndexInputData;
use JoyPla\Application\InputPorts\Web\Received\ReceivedIndexInputPortInterface;
use JoyPla\Application\InputPorts\Web\Received\ReceivedLabelInputData;
use JoyPla\Application\InputPorts\Web\Received\ReceivedLabelInputPortInterface;

class ReceivedController extends Controller
{
    
    public function orderList($vars) 
    {
        $body = View::forge('html/Received/OrderList', [], false)->render();
        echo view('html/Common/Template', compact('body'), false)->render();
    } 

    
    public function orderReceivedSlipIndex($vars, OrderReceivedSlipIndexInputPortInterface $inputPort ) 
    {
        $inputData = new OrderReceivedSlipIndexInputData(($this->request->user())->hospitalId,$vars['orderId']);
        $inputPort->handle($inputData);
    }

    public function register($vars)
    {
        $body = View::forge('html/Received/Register', [], false)->render();
        echo view('html/Common/Template', compact('body'), false)->render();
    }

    public function show($vars)
    {
        $body = View::forge('html/Received/Show', [], false)->render();
        echo view('html/Common/Template', compact('body'), false)->render();
    }

    public function index($vars, ReceivedIndexInputPortInterface $inputPort ) 
    {
        $inputData = new ReceivedIndexInputData(($this->request->user())->hospitalId,$vars['receivedId']);
        $inputPort->handle($inputData);
    }

    public function label($vars, ReceivedLabelInputPortInterface $inputPort ) 
    {
        $inputData = new ReceivedLabelInputData(($this->request->user())->hospitalId,$vars['receivedId']);
        $inputPort->handle($inputData);
    }
}
 