<?php

namespace JoyPla\InterfaceAdapters\Controllers\Api ;

use Csrf;
use framework\Http\Controller;
use JoyPla\Application\InputPorts\Api\ReceivedReturn\ReturnShowInputData;
use JoyPla\Application\InputPorts\Api\ReceivedReturn\ReturnShowInputPortInterface;

class ReturnController extends Controller
{
    public function show($vars , ReturnShowInputPortInterface $inputPort )
    {
        $token = $this->request->get('_csrf');
        Csrf::validate($token,true);
        $search = $this->request->get('search');
        
        $inputData = new ReturnShowInputData($this->request->user(), $search);
        $inputPort->handle($inputData);
    }
}
