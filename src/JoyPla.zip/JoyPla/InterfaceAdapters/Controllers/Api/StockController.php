<?php

namespace JoyPla\InterfaceAdapters\Controllers\Web ;

use App\SpiralDb\HospitalUser;
use Auth;
use framework\Http\Controller;
use framework\Http\View;
use JoyPla\Application\InputPorts\Web\Order\FixedQuantityOrderInputData;
use JoyPla\Application\InputPorts\Web\Order\FixedQuantityOrderInputPortInterface;
use JoyPla\Application\InputPorts\Web\Order\OrderIndexInputData;
use JoyPla\Application\InputPorts\Web\Order\OrderIndexInputPortInterface;

class StockController extends Controller
{

}

