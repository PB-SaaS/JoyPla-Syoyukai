<?php

namespace JoyPla\InterfaceAdapters\Controllers\Api ;

use Csrf;
use framework\Http\Controller;
use JoyPla\Application\InputPorts\Api\Order\OrderRegisterInputData;
use JoyPla\Application\InputPorts\Api\Order\OrderRegisterInputPortInterface;
use JoyPla\Application\InputPorts\Api\Order\OrderShowInputData;
use JoyPla\Application\InputPorts\Api\Order\OrderShowInputPortInterface;

class OrderController extends Controller
{
    
    public function register($vars , OrderRegisterInputPortInterface $inputPort ) 
    {
        global $SPIRAL;     
        $token = $this->request->get('_csrf');
        Csrf::validate($token,true);

        $orderItems = $this->request->get('orderItems');
        
        $inputData = new OrderRegisterInputData($SPIRAL->getContextByFieldTitle('hospitalId'), $orderItems );
        $inputPort->handle($inputData , 2);
    } 

    public function unapprovedShow($vars , OrderShowInputPortInterface $inputPort )
    {
        global $SPIRAL;
        $token = $this->request->get('_csrf');
        Csrf::validate($token,true);

        $inputData = new OrderShowInputData($SPIRAL->getContextByFieldTitle('hospitalId'),$this->request->get('search') );
        $inputPort->handle($inputData);
    }

    public function update($vars ) 
    {
    }
    
    public function delete($vars) 
    {
    }
}

 