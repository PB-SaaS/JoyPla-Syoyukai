<?php

namespace JoyPla\InterfaceAdapters\Presenters\Api\Order {

    use ApiResponse;
    use framework\Http\View;
    use JoyPla\Application\OutputPorts\Api\Order\OrderUnapprovedApprovalOutputData;
    use JoyPla\Application\OutputPorts\Api\Order\OrderUnapprovedApprovalOutputPortInterface;

    class OrderUnapprovedApprovalPresenter implements OrderUnapprovedApprovalOutputPortInterface
    {
        public function output(OrderUnapprovedApprovalOutputData $outputData)
        {
            $viewModel = new OrderUnapprovedApprovalViewModel($outputData);
            echo (new ApiResponse( $viewModel->data, $viewModel->count , $viewModel->code, $viewModel->message))->toJson();
        }
    }
        
    /**
     * Class Distributor
     * @package JoyPla\InterfaceAdapters\Presenters\Api\Order
     */
    class OrderUnapprovedApprovalViewModel
    {
        /**
         * Distributor constructor.
         * @param OrderUnapprovedApprovalOutputData $source
         */
        public function __construct(OrderUnapprovedApprovalOutputData $source)
        {
            $this->data = $source->data;
            $this->count = $source->count;
            $this->code = 200; 
            $this->message = "success";
        }
    }
}
