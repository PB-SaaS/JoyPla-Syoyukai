const vSelectDivision = {
  components :{
    'v-select' : vSelect,
  },
  props: {
    name: { 
        type: String, 
        required: true ,
        default: 'divisionId'
    },
    label: {
        type: String, 
        required: false,
        default: "", 
    },
    rules: {
        type: Object, 
        required: false, 
        default: {}
    },
    title: {
        type: String, 
        required: false, 
        default: ""
    },
  },
  watch: {
  },
  data() {
    return {
        options : [{ label: "----- 部署を選択してください -----" , value: "" }]
    }
  },
  mounted(){
      this.load();
  },
  methods: {
    load(){
      let self = this;
      let params = new URLSearchParams();
      params.append("path", "/api/division/show");
      params.append("_csrf", _CSRF);
      axios.post(_APIURL,params)
      .then( (response) => {
        let options = self.options;
        response.data.data.forEach(function(x,i){
          options.push({ label: x.divisionName, value: x.divisionId });
        });
        self.options = options;
      }) 
      .catch((error) => {
          console.log(error);
      });
    },
  },
  template: `
  <v-select :options="options" :name="name" :rules="rules" :title="title" :label="label"></v-select>
    ` 
};

const vMultipleSelectDivision = {
  components: {
    'v-multiple-select' : vMultipleSelect,
  },
  setup(props){
    const { ref , onMounted } = Vue; 

    const options = ref([]);
    const load = () =>{
      let self = this;
      let params = new URLSearchParams();
      params.append("path", "/api/division/show");
      params.append("_csrf", _CSRF);
      axios.post(_APIURL,params)
      .then( (response) => {
        response.data.data.forEach(function(x,i){
          options.value.push({ label: x.divisionName, value: x.divisionId });
        });
      }) 
      .catch((error) => {
          console.log(error);
      });
    };

    onMounted(() => {
      load();
    });

    return {
      options
    }
  },
  props: {
    name: { 
        type: String, 
        required: true ,
        default: 'divisionIds'
    },
    title: { 
        type: String, 
        required: true ,
        default: ''
    }
  },
  template: `
    <v-multiple-select
      :name="name"
      :title="title"
      :options="options"
      />
      `
};

const vMultipleSelectDistributor = {
  components: {
    'v-multiple-select' : vMultipleSelect,
  },
  setup(props){
    const { ref , onMounted } = Vue; 

    const options = ref([]);
    const load = () =>{
      let self = this;
      let params = new URLSearchParams();
      params.append("path", "/api/distributor/show");
      params.append("_csrf", _CSRF);
      axios.post(_APIURL,params)
      .then( (response) => {
        response.data.data.forEach(function(x,i){
          options.value.push({ label: x.distributorName, value: x.distributorId });
        });
      }) 
      .catch((error) => {
          console.log(error);
      });
    };

    onMounted(() => {
      load();
    });

    return {
      options
    }
  },
  props: {
    name: { 
        type: String, 
        required: true ,
        default: 'distributorIds'
    },
    title: { 
        type: String, 
        required: true ,
        default: ''
    }
  },
  template: `
    <v-multiple-select
      :name="name"
      :title="title"
      :options="options"
      />
      `
};

const vInHospitalItemModal = {
  setup(props , context){
      const { ref, toRef , toRefs , reactive , onMounted} = Vue;
      const { useForm } = VeeValidate;

      const loading = ref(false);
      const start = () => {
          loading.value = true;
      }

      const complete = () => {
          loading.value = false;
      }

      const sleepComplate = () => {
          window.setTimeout(function () {
              complete();
          }, 500);
      }
      start();
      
      onMounted( () => {
        sleepComplate()
      });

      const { meta , validate , values , setFieldValue} = useForm({
        initialValues: {
          itemName : "",
          makerName : "",
          itemCode : "",
          itemStandard : "",
          itemJANCode : "",
          distributorIds : [],
          perPage: "10",
          currentPage : 1,
        },
      });
      
      const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
          toast.addEventListener('mouseenter', Swal.stopTimer)
          toast.addEventListener('mouseleave', Swal.resumeTimer)
        }
      });

      const showPages = ref(5);
      const totalCount = ref(0);
      const inHospitalItems = ref([]);
      const currentTab = ref('list');
      const tabs = [
          {label: 'リスト' , value: 'list' , disabled: false},
          {label: '検索' , value: 'search' , disabled: false},
        ];
      const perPageOptions = [{ label: "10件表示", value: "10" },{ label: "50件表示", value: "50" },{ label: "100件表示", value: "100" }];

      const numberFormat = (value) => {
          if (! value ) { return 0; }
          return value.toString().replace( /([0-9]+?)(?=(?:[0-9]{3})+$)/g , '$1,' );
      };
      
      const searchExec = () => {
        listGet();
      };

      const searchCount = ref(0);

      const listGet = () => {
        let params = new URLSearchParams();
        params.append("path", "/api/inHospitalItem/show");
        params.append("search", JSON.stringify(encodeURIToObject(values)));
        params.append("_csrf", _CSRF);
        
        start();

        axios.post(_APIURL,params)
        .then( (response) => {
          inHospitalItems.value = response.data.data;
          totalCount.value = parseInt(response.data.count);
          currentTab.value = 'list';
        }) 
        .catch((error) => {
          complete();
          if(searchCount.value > 0){
            Toast.fire({
              icon: 'error',
              title: '検索に失敗しました。再度お試しください。'
            })
          }
          searchCount.value ++;
        })
        .then(() => {
          complete();
          if(searchCount.value > 0){
            Toast.fire({
              icon: 'success', 
              title: '検索が完了しました'
            })
          }
          searchCount.value ++;
        });
      };

      const getCurrentTab = (tab) => {
        currentTab.value = tab;
      };

      const currentPageEdited = ref(1);

      const changeParPage = () =>
      {
        currentPageEdited = 1;
        listGet();
      };
 
      const searchClear = () =>
      {
        setFieldValue('itemName', '');
        setFieldValue('makerName', '');
        setFieldValue('itemCode', '');
        setFieldValue('itemStandard', '');
        setFieldValue('itemJANCode', '');
        setFieldValue('distributorIds', []);
        listGet();
      };
      const add = (elem) => {
        context.emit('additem',elem);
        Toast.fire({
          icon: 'success',
          title: '反映しました'
        })
      };

      onMounted(() => {
        listGet();
      });

      return {
        loading, 
        start, 
        complete,
        currentPageEdited,
        values,
        searchExec,
        showPages,
        totalCount,
        inHospitalItems,
        currentTab,
        tabs,
        perPageOptions,
        listGet,
        getCurrentTab,
        changeParPage,
        searchClear,
        add,
        numberFormat
      }
  },
  emits: ['additem'], 
  components: {
    'v-loading': vLoading,
    'v-tab': vTab,
    'v-input': vInput,
    'v-select': vSelect,
    'v-select-division': vSelectDivision,
    'v-multiple-select-distributorId' : vMultipleSelectDistributor,
    'v-pagination' : vPagination,
    'v-open-modal' : vOpenModal,
    'v-button-default': vButtonDefault,
    'v-button-primary': vButtonPrimary,
    'v-input-number': vInputNumber,
    'item-view': itemView
  },
  watch:{
    currentPageEdited() {
      this.values.currentPage = this.currentPageEdited;
      this.listGet();
      document.getElementById('inHospitalItemsList').scrollTop = 0;
    },
  },
  methods: {
    
  },
  template: `
  <v-loading :show="loading"></v-loading>
  <v-button-default type="button" data-micromodal-trigger="inHospitalItemModal">商品検索</v-button-default>
  <v-open-modal id="inHospitalItemModal" headtext="商品検索">
    <div class="flex flex-col" style="max-height: 68vh;">
      <div>
        <v-tab ref="tab"
            :tabs="tabs"
            v-model:currentTab="currentTab"
            @currentTab="getCurrentTab"></v-tab>
      </div>
      <template v-if="currentTab === 'search'">
        <form class="w-full overflow-y-auto" style="max-height: 85vh;">
          <div class="flex flex-wrap">
            <div class="w-full px-3 my-6 md:mb-0">
              <div class="mx-auto lg:w-2/3 mb-4">
                <v-input 
                type="text"
                name="makerName"
                title="メーカー"></v-input>
              </div>
              <div class="mx-auto lg:w-2/3 mb-4">
                <v-input 
                type="text"
                name="itemName"
                title="商品名"></v-input>
              </div>
              <div class="mx-auto lg:w-2/3">
                <v-input 
                type="text"
                name="itemCode"
                title="製品コード"></v-input>
              </div>
              <div class="mx-auto lg:w-2/3 mb-4">
                <v-input 
                type="text"
                name="itemStandard"
                title="規格"></v-input>
              </div>
              <div class="mx-auto lg:w-2/3 mb-4">
                <v-input 
                type="text"
                name="itemJANCode" 
                title="JANコード"></v-input>
              </div>
              <div class="mx-auto lg:w-2/3 mb-4">
                <v-multiple-select-distributorId
                  name="distributorIds"
                  title="卸業者名"
                  ></v-multiple-select-distributorId>
              </div>
              <v-input type="hidden" name="perPage"></v-input>
              <div class="mx-auto lg:w-2/3 mb-4 text-center flex items-center gap-6 justify-center">
                <v-button-default type="button" v-on:click.native="searchClear">クリア</v-button-default>
                <v-button-primary type="button" v-on:click.native="searchExec">検索</v-button-primary>
              </div>
            </div>
          </div>
        </form>
      </template>
      <template v-else-if="currentTab === 'list'">
        <div class="flex">
          <div class="flex-none lg:w-1/4 w-full my-2">
            <v-select
              name="perPage"
              :options="perPageOptions"
              @change="changeParPage"
            ></v-select>
          </div>
        </div>
        <div>
          {{ (totalCount == 0)? 0 : ( parseInt(values.perPage) * ( values.currentPage - 1 ) ) + 1 }}件 - {{ (( parseInt(values.perPage) * values.currentPage )  < totalCount ) ?  parseInt(values.perPage) * values.currentPage : totalCount  }}件 / 全 {{ totalCount }}件
        </div>
        <div class="max-h-full overflow-y-auto" id="inHospitalItemsList">
          <div>
            <div class="w-full mb-8 xl:mb-0">
              <div class="hidden lg:flex w-full sticky top-0 bg-white py-4 flex-wrap">
                <div class="w-full lg:w-5/6">
                  <h4 class="font-bold font-heading text-gray-500 text-center">商品情報</h4>
                </div>
                <div class="w-full lg:w-1/6">
                  <h4 class="font-bold font-heading text-gray-500 text-center">反映</h4>
                </div>
              </div>
              <div class="lg:pt-0 pt-4"> 
                <div class="flex flex-wrap items-center mb-3" v-for="(elem, index) in inHospitalItems">
                  <div class="w-full lg:w-5/6 lg:px-4 px-0 mb-6 lg:mb-0">
                    <div class="flex flex-wrap items-center">
                      <div class="w-full lg:w-1/2">
                        <item-view class="w-full h-72"></item-view>
                      </div>
                      <div class="w-full lg:w-1/2 px-4 break-words">
                        <h3 class="text-xl font-bold font-heading">{{ elem.makerName }}</h3>
                        <p class="text-md font-bold font-heading">{{ elem.itemName }}</p>
                        <p class="text-gray-500">{{ elem.itemCode }}<br>{{ elem.itemStandard }}</p>
                        <p class="text-gray-500">{{ elem.quantity }}{{ elem.quantityUnit }} 入り</p>
                        <p>
                          <span class="text-xl text-orange-600 font-bold font-heading">&yen; {{ numberFormat(elem.price) }}</span><span class="text-gray-400"> ( &yen; {{ numberFormat(elem.unitPrice) }}/{{ elem.quantityUnit }} )</span>
                        </p>
                        <p class="text-gray-800">{{ elem.distributorName }}</p>
                      </div>
                    </div>
                  </div>
                  <div class="w-full lg:block lg:w-1/6 px-4 py-4">
                    <v-button-default type="button" class="w-full" v-on:click.native="add(elem)">反映</v-button-default>
                  </div>
                  <div class="py-2 px-4 w-full">
                    <div class="border-t border-gray-200"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div>
          <v-pagination 
                :showPages="showPages"
                v-model:currentPage="currentPageEdited"
                :totalCount="totalCount"
                :perPage="parseInt(values.perPage)"
              ></v-pagination>
        </div> 
      </template>
      <div class="hidden">
        <v-input type="hidden" name="makerName"></v-input>
        <v-input type="hidden" name="itemName"></v-input>
        <v-input type="hidden" name="itemCode"></v-input>
        <v-input type="hidden" name="itemStandard"></v-input>
        <v-input type="hidden" name="itemJANCode"></v-input>
        <v-input type="hidden" name="distributorIds"></v-input>
        <v-input type="hidden" name="currentPage"></v-input>
        <v-input type="hidden" name="perPage"></v-input>
      </div>
    </div>
    </v-open-modal>
    ` 
};