<!DOCTYPE html>
<html lang="ja">
<head>
    <title>JoyPla <?php echo $title; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="https://i02.smp.ne.jp/u/joypla/new/favicon.ico">
    <?php echo $head ?>
    <?php echo $style; ?>
    <link rel="stylesheet" href="https://i02.smp.ne.jp/u/joypla/new/css/normalize.css" />

    <!-- <link rel="stylesheet" href="https://i02.smp.ne.jp/u/joypla/new/css/animsition.min.css"> -->
    <!-- <script type="text/javascript" src="https://i02.smp.ne.jp/u/joypla/new/js/animsition.min.js"></script> -->

    <script src="https://i02.smp.ne.jp/u/joypla/new/js/JsBarcode.all.min.js"></script>
    <script src="https://i02.smp.ne.jp/u/joypla/new/js/BarcodeParser_20220331.js"></script>

    <script src="https://i02.smp.ne.jp/u/joypla/new/js/encoding.min.js"></script>
    
    <script src="https://unpkg.com/vue@3.2.36"></script>
    
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
    
    <script src="https://unpkg.com/vee-validate"></script>
    <script src="https://unpkg.com/@vee-validate/rules@next"></script>
    <script src="https://unpkg.com/@vee-validate/i18n@next"></script>
	
    <script src="https://unpkg.com/micromodal/dist/micromodal.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
    // import all the rules that come with vee-validate
    Object.keys(VeeValidateRules.default).forEach(rule => {
        VeeValidate.defineRule(rule, VeeValidateRules[rule])
    })
    
    VeeValidateI18n.loadLocaleFromURL('https://unpkg.com/@vee-validate/i18n@4.5.7/dist/locale/ja.json');
    VeeValidate.configure({
        // Generates an English message locale generator
        generateMessage: VeeValidateI18n.localize('ja'),
    });
    </script>

    <script>
        const encodeURIToObject = (object) => {
            let result = {};
            if(object == null){
                return null;
            }
            Object.keys(object).forEach(function (key) {
                if( typeof object[key] == "object"){
                result[key] = encodeURIToObject(object[key]);
                } else {
                result[key] = encodeURI(object[key]);
                }
            });
            return result;
        };
        
        const _CSRF = "<?php echo Csrf::generate(16) ?>";
        const _APIURL = "%url/rel:mpgt:ApiRoot%";
        const _ROOT = "%url/rel:mpgt:Root%";
    </script>

    <script>
        <?php
        require_once "JoyPla/resources/parts/component/form-components.php";
        require_once "JoyPla/resources/parts/component/components.php";
        require_once "JoyPla/resources/parts/component/v-loading.php";
        require_once "JoyPla/resources/parts/component/v-breadcrumbs.php";
        require_once "JoyPla/resources/parts/component/customVeeValidate.php";
        require_once "JoyPla/resources/parts/component/db-select-components.php";
        ?>
    </script>

    <style>
    <?php 
    require_once "JoyPla/resources/parts/output.css.php"; 
    ?>
    
    [v-cloak] {
      display: none;
    }
    </style>
    <?php echo $script; ?>
</head>
<body>
    <?php echo $body ?>
    <?php /*
    <div class="h-screen ">
        <v-loading :show="loading" id="joypla"></v-loading>
        <?php echo $header ?> 
        <div id="content" class="flex h-full px-1">
            <div class="flex-auto overflow-x-auto">
                <!-- 各アクションの内容を読み込む-->
                <?php echo $content; ?>
            </div>
        </div>
    </div>
    */ ?>
</body>
</html>