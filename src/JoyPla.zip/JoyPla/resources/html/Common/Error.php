<div
  class="
    flex
    items-center
    justify-center
    w-screen
    h-screen
    bg-gray-50
  "
>
  <div class="px-40 py-20">
    <div class="flex flex-col items-center">
      <h1 class="font-bold text-sushi-600 text-9xl"><?php echo $code ?></h1>

      <h6 class="mb-2 text-2xl font-bold text-center text-gray-800 md:text-3xl">
      <?php echo $message ?>
      </h6>
<?php /*
      <p class="mb-8 text-center text-gray-500 md:text-lg">
        お探しのページは存在しません。
      </p>
*/ ?>
    </div>
  </div>
</div>