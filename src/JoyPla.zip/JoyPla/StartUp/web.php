<?php
require_once "framework/Bootstrap/autoload.php";
require_once "JoyPla/require.php";
/** */

/** components */

use framework\Application;
use framework\Http\Request;
use framework\Http\View;
use framework\Routing\Router;
use JoyPla\Application\Interactors\Web\Consumption\ConsumptionIndexInteractor;
use JoyPla\InterfaceAdapters\Controllers\Web\ConsumptionController;
use JoyPla\InterfaceAdapters\Controllers\Web\OrderController;
use JoyPla\InterfaceAdapters\Controllers\Web\TopController;
use JoyPla\InterfaceAdapters\GateWays\Repository\ConsumptionRepository;
use JoyPla\InterfaceAdapters\Presenters\Web\Consumption\ConsumptionIndexPresenter;
use JoyPla\InterfaceAdapters\Presenters\Web\Consumption\ConsumptionPrintPresenter;

//SPIRALはすべてPOSTになる

const VIEW_FILE_ROOT = "JoyPla/resources";

Router::map('POST', '/top', function(Request $req){
    Router::redirect('/order/regist',$req);
})->service(new Request());

Router::map('POST', '/', [TopController:: class , 'index']);

Router::map('POST', '/order', [TopController:: class , 'orderpage']);

Router::map('POST', '/consumption', [TopController:: class , 'consumptionpage']);

Router::map('POST', '/consumption/regist', [ConsumptionController::class,'register']);

Router::map('POST', '/consumption/show', [ConsumptionController::class,'show']);

Router::map('POST', '/consumption/:consumptionId', [ConsumptionController::class,'index'])->service(new ConsumptionIndexInteractor(new ConsumptionIndexPresenter() , new ConsumptionRepository()) );

Router::map('POST', '/consumption/:consumptionId/print', [ConsumptionController::class,'print'])->service(new ConsumptionIndexInteractor(new ConsumptionPrintPresenter() , new ConsumptionRepository()) );

Router::map('POST', '/order/regist', [OrderController::class,'register']);

Router::map('POST', '/order/unapproved/show', [OrderController::class,'unapprovedShow']);

try{
    $router = new Router();
    $app = new Application();
    $kernel = new \framework\Http\Kernel($app, $router);
    $request = new Request();
    $kernel->handle($request);

} catch(Exception $e) {
    $body = View::forge('Hospital/html/Error', [
        'code' => $e->getCode(),
        'message' => $e->getMessage()
    ], false)->render();
    echo view('Template', compact('body'), false)->render();
}