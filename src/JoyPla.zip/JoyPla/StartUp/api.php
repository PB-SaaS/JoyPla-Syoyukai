<?php
require_once "framework/Bootstrap/autoload.php";
require_once "JoyPla/require.php";
require_once('NewJoyPla/model/Base.php');
/** */

/** components */

use framework\Application;
use framework\Http\Request;
use framework\Routing\Router;
use JoyPla\Application\Interactors\Api\Consumption\ConsumptionRegisterInteractor;
use JoyPla\Application\Interactors\Api\Consumption\ConsumptionShowInteractor;
use JoyPla\Application\Interactors\Api\Distributor\DistributorShowInteractor;
use JoyPla\Application\Interactors\Api\Division\DivisionShowInteractor;
use JoyPla\Application\Interactors\Api\InHospitalItem\InHospitalItemShowInteractor;
use JoyPla\Application\Interactors\Api\Order\OrderRegisterInteractor;
use JoyPla\Application\Interactors\Api\Order\OrderShowInteractor;
use JoyPla\InterfaceAdapters\Controllers\Api\ConsumptionController;
use JoyPla\InterfaceAdapters\Controllers\Api\DistributorController;
use JoyPla\InterfaceAdapters\Controllers\Api\DivisionController;
use JoyPla\InterfaceAdapters\Controllers\Api\InHospitalItemController;
use JoyPla\InterfaceAdapters\Controllers\Api\OrderController;
use JoyPla\InterfaceAdapters\GateWays\Repository\ConsumptionRepository;
use JoyPla\InterfaceAdapters\GateWays\Repository\DistributorRepository;
use JoyPla\InterfaceAdapters\GateWays\Repository\DivisionRepository;
use JoyPla\InterfaceAdapters\GateWays\Repository\InHospitalItemRepository;
use JoyPla\InterfaceAdapters\GateWays\Repository\OrderRepository;
use JoyPla\InterfaceAdapters\Presenters\Api\Consumption\ConsumptionRegisterPresenter;
use JoyPla\InterfaceAdapters\Presenters\Api\Consumption\ConsumptionShowPresenter;
use JoyPla\InterfaceAdapters\Presenters\Api\Distributor\DistributorShowPresenter;
use JoyPla\InterfaceAdapters\Presenters\Api\Division\DivisionShowPresenter;
use JoyPla\InterfaceAdapters\Presenters\Api\InHospitalItem\InHospitalItemShowPresenter;
use JoyPla\InterfaceAdapters\Presenters\Api\Order\OrderRegisterPresenter;
use JoyPla\InterfaceAdapters\Presenters\Api\Order\OrderUnapprovedShowPresenter;

//SPIRALはすべてPOSTになる

const VIEW_FILE_ROOT = "JoyPla/resources";

    
Router::map('POST','/api/division/show',[DivisionController::class , 'show'])->service(new DivisionShowInteractor(new DivisionShowPresenter() , new DivisionRepository()) );

Router::map('POST','/api/distributor/show',[DistributorController::class , 'show'])->service(new DistributorShowInteractor(new DistributorShowPresenter() , new DistributorRepository()) );

Router::map('POST','/api/inHospitalItem/show',[InHospitalItemController::class,'show'])->service(new InHospitalItemShowInteractor(new InHospitalItemShowPresenter() , new InHospitalItemRepository()) );

Router::map('POST','/api/consumption/register',[ConsumptionController::class,'register'])->service(new ConsumptionRegisterInteractor(new ConsumptionRegisterPresenter() , new ConsumptionRepository()) );

Router::map('POST','/api/consumption/show',[ConsumptionController::class,'show'])->service(new ConsumptionShowInteractor(new ConsumptionShowPresenter() , new ConsumptionRepository()) );

Router::map('POST','/api/order/register',[OrderController::class,'register'])->service(new OrderRegisterInteractor(new OrderRegisterPresenter() , new OrderRepository()) );

Router::map('POST','/api/order/unapproved/show',[OrderController::class,'unapprovedShow'])->service(new OrderShowInteractor(new OrderUnapprovedShowPresenter() , new OrderRepository()) );

try{
    $router = new Router();
    $app = new Application();
    $kernel = new \framework\Http\Kernel($app, $router);
    $request = new Request();
    $kernel->handle($request);
} catch(Exception $e) {
    echo (new ApiResponse( [], 0 , $e->getCode(), $e->getMessage()))->toJson();
}