<?php
namespace App\SpiralDb;
use SpiralORM;

class HospitalUser extends SpiralORM
{
    const CREATED_AT = "registrationTime";
    const UPDATED_AT = "updateTime";
    const DELETED_AT = "";

    public static $spiral_db_name = "NJ_HUserDB";
    public static $guarded = ["id"];
    public static $primary_key = "loginId";
    public static $mail_field_title = "mailAddress";
    public static $fillable = [
        "registrationTime",
        "updateTime",
        "authKey",
        "hospitalId",
        "divisionId",
        "userPermission",
        "loginId",
        "loginPassword",
        "name",
        "nameKana",
        "mailAddress",
        "remarks",
        "termsAgreement",
        "tenantId",
        "agreementDate",
        "hospitalAuthKey",
        "userCheck"
    ];

    //デフォルト値
    public static $attributes = [];

    public static $select = [];

    public function isHospitalUser(){
        if($this->userCheck == '1')
        {
            return true;
        }
        return false;
    }

    public function isDistributorUser(){
        if($this->userCheck == '2')
        {
            return true;
        }
        return false;
    }
    
    public function isAdmin(){
        if($this->userCheck == '1')
        {
            return true;
        }
        return false;
    }

    public function isUser(){
        if($this->userCheck  == '2')
        {
            return true;
        }
        return false;
    }
    
    
    public function isApprover(){
        if($this->userCheck == '3')
        {
            return true;
        }
        return false;
    }
} 
