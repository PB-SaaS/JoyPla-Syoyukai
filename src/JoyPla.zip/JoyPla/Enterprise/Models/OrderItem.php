<?php

namespace JoyPla\Enterprise\Models;

use Collection;
class OrderItem 
{
    private OrderId $orderId;
    private InHospitalItemId $inHospitalItemId;
    private Item $item;
    private HospitalId $hospitalId;
    private Division $division;
    private Distributor $distributor;
    private Quantity $quantity;
    private Price $price;
    private int $orderQuantity;
    private bool $lotManagement;

    public function __construct(
        OrderId $orderId,
        InHospitalItemId $inHospitalItemId,
        Item $item,
        HospitalId $hospitalId,
        Division $division,
        Distributor $distributor,
        Quantity $quantity,
        Price $price,
        int $orderQuantity,
        bool $lotManagement
        )
    {
        $this->orderId = $orderId;
        $this->inHospitalItemId = $inHospitalItemId;
        $this->item = $item;
        $this->hospitalId = $hospitalId;
        $this->division = $division;
        $this->distributor = $distributor;
        $this->quantity = $quantity;
        $this->price = $price;
        $this->orderQuantity = $orderQuantity;
        $this->lotManagement = $lotManagement;
    }

    public static function create( Collection $input )
    {
        return new OrderItem(
            (new OrderId($input->orderNumber) ),
            (new InHospitalItemId($input->inHospitalItemId) ),
            (Item::create($input) ),
            (new HospitalId($input->hospitalId) ),
            (Division::create($input) ),
            (Distributor::create($input) ),
            (Quantity::create($input) ),
            (new Price($input->price) ),
            (int) $input->orderQuantity ,
            (int) $input->lotManagement 
        );
    }

    public function getDivision()
    {
        return $this->division;
    }

    public function getDistributor()
    {
        return $this->distributor;
    }


    public function equalDivision(Division $division)
    {
        return $this->division === $division;
    }

    public function equalOrderSlip(Division $division , Distributor $distributor)
    {
        return (
            $this->division->getDivisionId()->value() === $division->getDivisionId()->value() && 
            $this->distributor->getDistributorId()->value() === $distributor->getDistributorId()->value()
        );
    }

    public function price(){
        return $this->price->value() * $this->orderQuantity;
    }
    
    public function getInHospitalItemId(){
        return $this->inHospitalItemId;
    }

    public function toArray()
    {
        return [
            'orderId' => $this->orderId->value(),
            'inHospitalItemId' => $this->inHospitalItemId->value(),
            'item' => $this->item->toArray(),
            'hospitalId' => $this->hospitalId->value(),
            'division' => $this->division->toArray(),
            'distributor' => $this->distributor->toArray(),
            'quantity' => $this->quantity->toArray(),
            'price' => $this->price->value(),
            'orderQuantity' => $this->orderQuantity,
            'orderPrice' => $this->price(),
            'lotManagement' => $this->lotManagement,
        ];
    }
}