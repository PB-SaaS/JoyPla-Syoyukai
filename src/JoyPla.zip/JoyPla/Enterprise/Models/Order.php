<?php

namespace JoyPla\Enterprise\Models;

use Collection;
class Order
{
    private OrderId $orderId;
    private DateYearMonthDay $orderDate;
    private array $orderItems;
    private Hospital $hospital;
    private Division $division;
    private Distributor $distributor;
    private OrderStatus $orderStatus;
    private int $adjustment;

    public function __construct(
        OrderId $orderId,
        DateYearMonthDay $orderDate,
        array $orderItems,
        Hospital $hospital,
        Division $division,
        Distributor $distributor,
        OrderStatus $orderStatus,
        int $adjustment
        )
    {
        
        $this->orderId = $orderId;
        $this->orderDate = $orderDate;
        $this->orderItems = array_map(function(OrderItem $v){
            return $v;
        },$orderItems);
        $this->hospital = $hospital;
        $this->division = $division;
        $this->distributor = $distributor;
        $this->orderStatus = $orderStatus;
        $this->adjustment = $adjustment;
    }

    public static function create( Collection $input)
    {
        return new Order(
            (new OrderId($input->orderNumber) ),
            (new DateYearMonthDay($input->orderTime) ),
            [],
            (Hospital::create($input) ),
            (Division::create($input) ),
            (Distributor::create($input) ),
            (new OrderStatus($input->orderStatus) ),
            $input->adjustment
        );
    }
    public function getOrderId()
    {
        return $this->orderId;
    }

    public function getDivision()
    {
        return $this->division;
    }

    public function getDistributor()
    {
        return $this->distributor;
    }

    public function equalOrderSlip(Division $division , Distributor $distributor)
    {
        return (
            $this->division->getDivisionId()->value() === $division->getDivisionId()->value() && 
            $this->distributor->getDistributorId()->value() === $distributor->getDistributorId()->value()
        );
    }

    public function totalAmount(){
        $num = 0;
        foreach($this->orderItems as $item)
        {
            $num += $item->price();
        }
        return $num;
    }

    
    public function itemCount(){
        $array = [];
        foreach($this->orderItems as $item)
        {
            $array[] = $item->getInHospitalItemId()->value();
        }
        return count(array_unique($array));
    }

    public function addOrderItem(OrderItem $item)
    {
        $items = $this->orderItems;
        $items[] = $item;
        return $this->setOrderItems($items);
    }

    public function setOrderItems(array $orderItems)
    {
        $orderItems = array_map(function(OrderItem $v){
            return $v;
        },$orderItems);

        return new Order(
            $this->orderId,
            $this->orderDate,
            $orderItems,
            $this->hospital,
            $this->division,
            $this->distributor,
            $this->orderStatus,
            $this->adjustment
        );
    }

    public function toArray()
    {
        return [
            'orderId' => $this->orderId->value(),
            'orderDate' => $this->orderDate->value(),
            'orderItems' =>  array_map(function(OrderItem $v){
                return $v->toArray();
            },$this->orderItems),
            'hospital' => $this->hospital->toArray(),
            'division' => $this->division->toArray(),
            'distributor' => $this->distributor->toArray(),
            'orderStatus' => $this->orderStatus->value(),
            'orderStatusToString' => $this->orderStatus->toString(),
            'totalAmount' => $this->totalAmount(),
            'itemCount' => $this->itemCount(),
            'adjustment' => $this->adjustment,
        ];
    } 
}