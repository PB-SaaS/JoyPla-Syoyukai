<?php
include_once 'NewJoyPla/lib/ApiSpiral.php';
include_once "NewJoyPla/lib/Define.php";
include_once 'NewJoyPla/lib/SpiralDataBase.php';
include_once 'NewJoyPla/lib/UserInfo.php';
include_once 'NewJoyPla/api/RegReturn.php';
include_once 'NewJoyPla/api/RegInventoryTrdb.php';
include_once 'NewJoyPla/api/GetDivision.php';


$userInfo = new App\Lib\UserInfo($SPIRAL);

$spiralApiCommunicator = $SPIRAL->getSpiralApiCommunicator();
$spiralApiRequest = new SpiralApiRequest();
$spiralDataBase = new App\Lib\SpiralDataBase($SPIRAL,$spiralApiCommunicator,$spiralApiRequest);

$regReturn = new App\Api\RegReturn($spiralDataBase,$userInfo);
$result = $regReturn->register($_POST['receivingHistoryId'],$_POST['distributorId'],$_POST['returnData']);
if(! $result){
var_dump($result);
	echo json_encode(array('result'=>$result));
	exit;
}


$getDivision = new App\Api\GetDivision($spiralDataBase,$userInfo);
$divisionData = $getDivision->select();
if($divisionData['code'] != '0'){
	echo json_encode(array('result'=>false));
	exit;
}

$regInventoryTrdb = new App\Api\RegInventoryTrdb($spiralDataBase,$userInfo);

$remakeData = array();

foreach($_POST['returnData'] as $itemId => $data){
	$remakeData[$itemId] = array();
	$remakeData[$itemId]['countNum'] = $data['quantity'] * $data['returnCount'];
}

$result = $regInventoryTrdb->orderCount($remakeData,$divisionData['store'][0][1],'2');

if(! $result){
	var_dump($result);
	echo json_encode(array('result'=>$result));
	exit;
}

echo json_encode(array('result'=>$result));