<?php
declare(strict_types=1);

namespace NGT\Barcode\GS1Decoder\Contracts\Identifiers;

interface VariableLength
{
    //
}
