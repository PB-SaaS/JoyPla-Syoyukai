<?php echo $name ?> 様

JoyPla からお知らせです。

<?php echo $text ?> がされましたので、下記の通りお知らせします。

[卸業者]

業者名 <?php echo $distributorName ?>

担当者 <?php echo $staffName ?>


[発注内容]

発注日時 <?php echo $orderTime ?> 

発注番号 <?php echo $orderNumber ?> 

発注品目 <?php echo $itemsNumber ?> (品目) 
 
合計金額 <?php echo $totalAmount ?> 

下記URLよりログインしてご確認ください 
<?php echo $url ?>  

※このメールへの返信は受け付けていません。 