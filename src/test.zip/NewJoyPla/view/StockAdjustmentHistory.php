<div class="animsition" uk-height-viewport="expand: true">
	  	<div class="uk-section uk-section-default uk-preserve-color uk-padding-remove uk-margin-top" id="page_top">
		    <div class="uk-container uk-container-expand">
		    	<ul class="uk-breadcrumb no_print">
				    <li><a href="%url/rel:mpg:top%">TOP</a></li>
                	<li><a href="%url/rel:mpg:top%&path=stock">在庫メニュー</a></li>
				    <li><span>在庫調整ログ</span></li>
				</ul>
		    	<div class='uk-width-1-1' uk-grid>
		    		<div class="uk-width-3-4@m">
		    			<h2>在庫調整ログ</h2>
					</div>
		    	</div>
		    	<hr>
		    	<div class="uk-margin-auto uk-width-4-5@m">
				%sf:usr:search33:table%
				</div>
			</div>
		</div>
	</div>