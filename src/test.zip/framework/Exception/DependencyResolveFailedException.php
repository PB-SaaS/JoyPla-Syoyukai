<?php


namespace framework\Exception;

use Exception;

class DependencyResolveFailedException extends Exception
{
}