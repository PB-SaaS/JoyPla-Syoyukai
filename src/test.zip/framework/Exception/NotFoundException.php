<?php


namespace framework\Exception;

use Exception;

class NotFoundException extends Exception
{
}