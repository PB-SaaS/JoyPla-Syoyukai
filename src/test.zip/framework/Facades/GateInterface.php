<?php

namespace JoyPla\Enterprise\CommonModels;

Interface GateInterface
{
    public function can();
}