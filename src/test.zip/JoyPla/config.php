<?php
require_once "Library/require.php";
require_once "Define.php";

define('MY_AREA_TITLE', "NJ_HPLogin");
define('OROSHI_MY_AREA_TITLE', "NJ_OUser");

define('FROM_ADDRESS', "joypla-spd@pi-pe.co.jp");
define('FROM_NAME', "joypla");
define('HP_MAIL_FIELD_TITLE', "mailAddress");
define('OROSHI_MAIL_FIELD_TITLE', "mailAddress");

